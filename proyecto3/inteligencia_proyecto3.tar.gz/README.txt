************* PROYECTO 3 - CNF, SAT ***************

Ejecucion del proyecto:

./sudoku_solver.sh <nombre_archivo_instancias> <nombre_archivo_soluciones>
